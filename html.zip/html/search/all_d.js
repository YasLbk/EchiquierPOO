var searchData=
[
  ['roi',['Roi',['../class_roi.html',1,'Roi'],['../class_roi.html#af865dc56460d43c52fabaf7c3f6e1dfb',1,'Roi::Roi()']]]
];
