var searchData=
[
  ['add_5fto_5fhist',['add_to_hist',['../_historique_8cpp.html#a58ac16709f1c8a2fe638697811aaa5a3',1,'add_to_hist(string name):&#160;Historique.cpp'],['../_historique_8h.html#a58ac16709f1c8a2fe638697811aaa5a3',1,'add_to_hist(string name):&#160;Historique.cpp']]],
  ['adv_5fenechec',['adv_enechec',['../class_echiquier.html#a872ee2de071f5441632fa3ccce175f50',1,'Echiquier']]],
  ['affiche',['affiche',['../class_echiquier.html#af22265120d527dfb2fa91187c4ce01cf',1,'Echiquier::affiche()'],['../class_jeu.html#a7931f8054847abc19e33e73967a3807e',1,'Jeu::affiche()'],['../class_piece.html#aa9a37e03a0d6bcd4c5e41a7c2e5103bf',1,'Piece::affiche()'],['../class_tour.html#abc82d80a3a618ed209fb288cee7c7a4e',1,'Tour::affiche()'],['../class_cavalier.html#abfb1fa4cd3a2108f63ef83de8368b435',1,'Cavalier::affiche()'],['../class_fou.html#a8b13617bdc15a92c75d02efd35d773fc',1,'Fou::affiche()'],['../class_dame.html#ad5ff4e1b20e15a39ad6dec1aecb288dd',1,'Dame::affiche()'],['../class_roi.html#a85b1dcea2a1d3dd6b34b7e05aa644b12',1,'Roi::affiche()'],['../class_pion.html#a4bdef5e46086ed68c1a1bf87f60c03ab',1,'Pion::affiche()']]],
  ['alg_5fto_5fnumcoord',['alg_to_numcoord',['../class_square.html#af5bfe4d8934e771d14b97c09912463e7',1,'Square']]],
  ['alloc_5fmem_5fechiquier',['alloc_mem_echiquier',['../class_echiquier.html#af0b47dd985820c255f9bba385dc101bc',1,'Echiquier']]]
];
