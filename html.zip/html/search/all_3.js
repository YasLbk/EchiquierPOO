var searchData=
[
  ['dame',['Dame',['../class_dame.html',1,'Dame'],['../class_dame.html#acb39f50cf492bdc8338c73f3a26aabe3',1,'Dame::Dame()']]],
  ['deplace',['deplace',['../class_echiquier.html#af1392118fed421846b90f87411de3836',1,'Echiquier::deplace()'],['../class_jeu.html#a469681711e72ed87a51c61842bf5bf54',1,'Jeu::deplace()']]]
];
