var searchData=
[
  ['piecesb',['piecesb',['../class_echiquier.html#afaaa07b9c719c527459313ab96b04330',1,'Echiquier']]],
  ['piecesn',['piecesn',['../class_echiquier.html#a29f7fc21513604c46bee4b1414873fb9',1,'Echiquier']]],
  ['pionsb',['pionsb',['../class_echiquier.html#a773c19fc526859bd431016cd5331112f',1,'Echiquier']]],
  ['pionsn',['pionsn',['../class_echiquier.html#af2948ef643505299286f0e008b01cea4',1,'Echiquier']]]
];
