var searchData=
[
  ['noir',['Noir',['../_piece_8h.html#aa304d0ca681f782b1d7735da33037dd7aa7b5bb6c14d7e04bce22bf5ee184be20',1,'Piece.h']]]
];
