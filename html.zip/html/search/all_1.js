var searchData=
[
  ['blanc',['Blanc',['../_piece_8h.html#aa304d0ca681f782b1d7735da33037dd7a58b0623118011f228f9e035e740ca481',1,'Piece.h']]]
];
