var searchData=
[
  ['nbcol',['NBCOL',['../_echiquier_8cpp.html#a8f8cd1540fdc837cee034be5be8c2aa5',1,'NBCOL():&#160;Echiquier.cpp'],['../_piece_8cpp.html#a8f8cd1540fdc837cee034be5be8c2aa5',1,'NBCOL():&#160;Piece.cpp']]]
];
