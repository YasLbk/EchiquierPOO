var searchData=
[
  ['petitroque',['petitroque',['../class_echiquier.html#a620271447c75c9f8da54d60fd149daac',1,'Echiquier']]],
  ['piece',['Piece',['../class_piece.html#a820acd2f9fc2b48368f50398f2656a69',1,'Piece']]],
  ['pion',['Pion',['../class_pion.html#a498c7f64335b26d4c976d80e32169578',1,'Pion']]],
  ['pose_5fpiece',['pose_piece',['../class_echiquier.html#a2e022b0075e8b2998ea8a3810713e07a',1,'Echiquier']]]
];
